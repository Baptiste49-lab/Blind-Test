package fr.esaip.blindtest.activities;

import android.content.Intent;
import android.graphics.Color;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.speech.RecognizerIntent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

import fr.esaip.blindtest.R;
import fr.esaip.blindtest.models.Difficulty;

public class GameActivity extends AppCompatActivity {

    private static final int SPEECH_REQUEST_CODE = 100;

    private Difficulty currentMode = Difficulty.FACILE;
    private String currentGenre = "Pop";
    private int maxTracks = 10;

    private int currentTrackIndex = 0;
    private long startTime;
    private int score = 0;
    private int combo = 0;
    private CountDownTimer timer;

    private TextView tvTimer, tvScore;
    private LinearLayout layoutQCM, layoutInput;
    private View mainLayout;
    private ImageButton btnMic;
    private EditText etAnswer;
    private Button[] btnReps = new Button[4];

    private RequestQueue requestQueue;
    private MediaPlayer mediaPlayer;
    private List<Track> trackList = new ArrayList<>();
    private Track currentTrack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        mainLayout = findViewById(R.id.mainGameLayout);
        tvTimer = findViewById(R.id.tvTimer);
        tvScore = findViewById(R.id.tvScore);
        layoutQCM = findViewById(R.id.layoutQCM);
        layoutInput = findViewById(R.id.layoutInput);
        btnMic = findViewById(R.id.btnMic);
        etAnswer = findViewById(R.id.etAnswer);
        btnReps[0] = findViewById(R.id.btnRep1);
        btnReps[1] = findViewById(R.id.btnRep2);
        btnReps[2] = findViewById(R.id.btnRep3);
        btnReps[3] = findViewById(R.id.btnRep4);

        // Récupération des paramètres de ConfigActivity
        Intent intent = getIntent();
        if (intent.hasExtra("DIFFICULTY_MODE")) currentMode = Difficulty.valueOf(intent.getStringExtra("DIFFICULTY_MODE"));
        if (intent.hasExtra("GENRE")) currentGenre = intent.getStringExtra("GENRE");
        if (intent.hasExtra("TRACK_COUNT")) maxTracks = intent.getIntExtra("TRACK_COUNT", 10);

        requestQueue = Volley.newRequestQueue(this);
        setupMediaPlayer();
        setupMicButton();

        etAnswer.setOnEditorActionListener((v, actionId, event) -> {
            checkTextAnswer(etAnswer.getText().toString());
            return true;
        });

        // Lancement de la requête API Deezer
        fetchDeezerTracks();
    }

    private void setupMediaPlayer() {
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioAttributes(new AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .build());
    }

    private void fetchDeezerTracks() {
        // Recherche générique via l'API Deezer, limit=50 pour avoir du choix
        String url = "https://api.deezer.com/search/track?q=" + currentGenre + "&limit=50";

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    try {
                        JSONArray data = response.getJSONArray("data");
                        for (int i = 0; i < data.length(); i++) {
                            JSONObject trackObj = data.getJSONObject(i);
                            String title = trackObj.getString("title_short");
                            String preview = trackObj.getString("preview");

                            // Certains titres sur Deezer n'ont pas de preview MP3 (droits d'auteur)
                            if (!preview.isEmpty() && !preview.equals("null")) {
                                trackList.add(new Track(title, preview));
                            }
                        }
                        // Mélange les musiques pour que les parties soient uniques
                        Collections.shuffle(trackList);
                        setupGameMode();
                        startNewTrack();
                    } catch (Exception e) {
                        Toast.makeText(this, "Erreur de lecture du JSON", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(this, "Erreur réseau avec Deezer", Toast.LENGTH_SHORT).show()
        );
        requestQueue.add(request);
    }

    private void setupGameMode() {
        if (currentMode == Difficulty.DIFFICILE) {
            layoutQCM.setVisibility(View.GONE);
            layoutInput.setVisibility(View.VISIBLE);
        } else {
            layoutQCM.setVisibility(View.VISIBLE);
            layoutInput.setVisibility(View.GONE);

            View.OnClickListener qcmListener = v -> {
                Button b = (Button) v;
                boolean isCorrect = b.getText().toString().equalsIgnoreCase(currentTrack.title);
                handleAnswer(isCorrect);
            };
            for (Button b : btnReps) b.setOnClickListener(qcmListener);
        }
    }

    private void startNewTrack() {
        if (currentTrackIndex >= maxTracks || currentTrackIndex >= trackList.size()) {
            Toast.makeText(this, "Partie terminée ! Score : " + score, Toast.LENGTH_LONG).show();
            // Optionnel : Envoyer le score sur Firebase Firestore ici
            finish();
            return;
        }

        currentTrack = trackList.get(currentTrackIndex);
        etAnswer.setText("");

        if (currentMode != Difficulty.DIFFICILE) {
            // Génération dynamique du QCM avec 3 fausses réponses
            List<String> choices = new ArrayList<>();
            choices.add(currentTrack.title);
            while (choices.size() < 4) {
                String randomTitle = trackList.get((int) (Math.random() * trackList.size())).title;
                if (!choices.contains(randomTitle)) choices.add(randomTitle);
            }
            Collections.shuffle(choices); // Pour ne pas que la bonne réponse soit toujours le btn1
            for (int i = 0; i < 4; i++) btnReps[i].setText(choices.get(i));
        }

        playMusic(currentTrack.previewUrl);
    }

    private void playMusic(String url) {
        try {
            mediaPlayer.reset();
            mediaPlayer.setDataSource(url);
            mediaPlayer.prepareAsync(); // Téléchargement asynchrone sans bloquer l'écran
            mediaPlayer.setOnPreparedListener(mp -> {
                mp.start();
                startTime = System.currentTimeMillis();
                startTimer();
            });
        } catch (Exception e) {
            e.printStackTrace();
            handleAnswer(false); // Passe à la suivante si la musique plante
        }
    }

    private void startTimer() {
        if (timer != null) timer.cancel();
        timer = new CountDownTimer(currentMode.getTimeLimit(), 1000) {
            public void onTick(long millisUntilFinished) {
                tvTimer.setText((millisUntilFinished / 1000) + "s");
            }
            public void onFinish() {
                tvTimer.setText("0s");
                handleAnswer(false);
            }
        }.start();
    }

    private void checkTextAnswer(String input) {
        String cleanInput = input.trim().toLowerCase().replaceAll("[éèê]", "e");
        String cleanExpected = currentTrack.title.trim().toLowerCase().replaceAll("[éèê]", "e");
        boolean isCorrect = calculateLevenshteinDistance(cleanInput, cleanExpected) <= 2;
        handleAnswer(isCorrect);
    }

    private void handleAnswer(boolean isCorrect) {
        if (timer != null) timer.cancel();
        if (mediaPlayer.isPlaying()) mediaPlayer.stop();

        currentTrackIndex++;

        if (isCorrect) {
            long timeTaken = System.currentTimeMillis() - startTime;
            int points = Math.max(100, 1000 - (int)(timeTaken / 1000) * 50);
            combo++;
            double multiplier = combo >= 3 ? 1.5 : 1.0;
            score += (points * multiplier);

            mainLayout.setBackgroundColor(Color.parseColor("#1B5E20"));
            if (combo >= 3) Toast.makeText(this, "COMBO x1.5 !", Toast.LENGTH_SHORT).show();
        } else {
            combo = 0;
            mainLayout.setBackgroundColor(Color.parseColor("#B71C1C"));
            Toast.makeText(this, "C'était : " + currentTrack.title, Toast.LENGTH_LONG).show();
        }

        tvScore.setText("Score: " + score);

        new Handler().postDelayed(() -> {
            mainLayout.setBackgroundColor(Color.parseColor("#121212"));
            startNewTrack();
        }, 2000);
    }

    // Gestion du micro (Mode Difficile)
    private void setupMicButton() {
        btnMic.setOnClickListener(v -> {
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
            try {
                startActivityForResult(intent, SPEECH_REQUEST_CODE);
            } catch (Exception e) {
                Toast.makeText(this, "Reconnaissance vocale non supportée", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SPEECH_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                etAnswer.setText(results.get(0));
                checkTextAnswer(results.get(0));
            }
        }
    }

    private int calculateLevenshteinDistance(String a, String b) {
        int[][] dp = new int[a.length() + 1][b.length() + 1];
        for (int i = 0; i <= a.length(); i++) {
            for (int j = 0; j <= b.length(); j++) {
                if (i == 0) { dp[i][j] = j; }
                else if (j == 0) { dp[i][j] = i; }
                else {
                    dp[i][j] = Math.min(dp[i - 1][j - 1] + (a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1),
                            Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1));
                }
            }
        }
        return dp[a.length()][b.length()];
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (timer != null) timer.cancel();
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
        if (requestQueue != null) requestQueue.cancelAll(tag -> true);
    }

    // Classe interne pour stocker chaque musique
    private static class Track {
        String title;
        String previewUrl;
        Track(String title, String previewUrl) {
            this.title = title;
            this.previewUrl = previewUrl;
        }
    }
}