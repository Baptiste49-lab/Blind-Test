package fr.esaip.blindtest.activities; // Vérifie ton nom de package

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioGroup;
import androidx.appcompat.app.AppCompatActivity;

import fr.esaip.blindtest.R; // Vérifie ton nom de package
import com.google.firebase.auth.FirebaseAuth;

public class ConfigActivity extends AppCompatActivity {

    private RadioGroup rgDifficulty;
    private Button btnPlay, btnLogout;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_config);

        mAuth = FirebaseAuth.getInstance();
        rgDifficulty = findViewById(R.id.rgDifficulty);
        btnPlay = findViewById(R.id.btnPlay);
        btnLogout = findViewById(R.id.btnLogout);

        // Lancement du jeu
        btnPlay.setOnClickListener(v -> startGame());

        // Déconnexion Firebase
        btnLogout.setOnClickListener(v -> {
            mAuth.signOut();
            startActivity(new Intent(ConfigActivity.this, AuthActivity.class));
            finish();
        });
    }

    private void startGame() {
        int selectedId = rgDifficulty.getCheckedRadioButtonId();
        String difficultyMode = "MOYEN"; // Valeur par défaut

        if (selectedId == R.id.rbFacile) {
            difficultyMode = "FACILE";
        } else if (selectedId == R.id.rbDifficile) {
            difficultyMode = "DIFFICILE";
        }

        Intent intent = new Intent(ConfigActivity.this, GameActivity.class);
        intent.putExtra("DIFFICULTY_MODE", difficultyMode);
        startActivity(intent);
    }
}